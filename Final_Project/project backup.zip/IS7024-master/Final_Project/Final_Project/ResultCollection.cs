﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Final_Project
{
    public class ResultsCollection
    {
        private List<Result> results;

        public List<Result> Results { get => results; set => results = value; }
    }
}